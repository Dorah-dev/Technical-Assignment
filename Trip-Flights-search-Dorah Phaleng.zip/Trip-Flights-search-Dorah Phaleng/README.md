

1. `flights search` triggers the command line tool
1. Follow the instructions to
  * Select what airport you're flying from
  * Select what airport you're flying to
  * The departure date range that you're searching over
  * The departure time of day you're searching over (i.e. "I only want to look for flights between 3-6 PM")
  * Select if you only want to look at round-trip flights
  * Select maximum total price of flights in USD
  * Select if you only want to look at direct flights
1. You'll (hopefully) get a list of flights - after selecting one, you'll be taken to a `kiwi.com` booking page

